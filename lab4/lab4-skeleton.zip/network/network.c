/*
 * network/network.c: implementation of the MNP process. 
 *
 * CS60, March 2018. 
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <signal.h>
#include <netdb.h>
#include <assert.h>
#include <sys/utsname.h>
#include <pthread.h>
#include <unistd.h>

#include "../common/constants.h"
#include "../common/pkt.h"
#include "../common/seg.h"
#include "../topology/topology.h"
#include "network.h"
#include "nbrcosttable.h"
#include "dvtable.h"
#include "routing_table.h"

/**************** constants ****************/
#define NETWORK_WAITTIME 60

/**************** global variables ****************/
int overlay_connection; 		//connection to the overlay
int transport_connection; 	//connection to the transport
nbr_cost_entry_t *nbr_cost_table; //neighbor cost table
dv_t *dv_table; 									//distance vector table
pthread_mutex_t *dv_mutex; 				//dvtable mutex
routingtable_t *routing_table; 		//routing table
pthread_mutex_t *routingtable_mutex; //routing_table mutex

/**************** local function prototypes ****************/
int connectToOverlay(); 
void *routeupdate_daemon(void *arg); 
void *pkthandler(void *arg); 
void waitTransport(); 
void network_stop(); 

/**************** main function ****************/
/* TODO: entry point for the network: 
 *  1) initialize neighbor cost table, distance vector table, mutex
 *     routing table, connections to overlay and transport
 *  2) print out the three tables
 *  3) set up signal handler for SIGINT 
 * 	4) set up overlay connection 
 *  5) create packet handling thread
 *  6) create route update thread
 *  7) wait NETWORK_WAITTIME for routes to be established and then 
 *     print routing table
 *  8) wait for the MRT process to connect (waitTransport())
 */
int main(int argc, char *argv[]) {
	printf("network layer is starting, pls wait...\n");

	// wait connection from MRT process
	printf("waiting for connection from MRT process...\n");
	waitTransport();

	return 0;
}

/**************** local functions ****************/

// This function is used to for the network layer process to 
// connect to the local overlay process on port OVERLAY_PORT. 
// return connection descriptor if success, -1 otherwise. 
// Pseudocode
// 1) Fill in sockaddr_in for socket
// 2) Create socket
// 3) return the socket descriptor 
int connectToOverlay() {
	struct sockaddr_in servaddr;

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(OVERLAY_PORT);

	int overlay_conn = socket(AF_INET, SOCK_STREAM, 0);
	if (overlay_conn < 0)
		return -1;
	if (connect(overlay_conn, (struct sockaddr *) &servaddr, sizeof(servaddr)) != 0)
		return -1;

	// successfully connected
	return overlay_conn;
}

// TODO: This thread handles incoming packets from the ON process.   
// Pseudocode
// 1) while recv packet from overlay connection
// 2) 	if it is a ROUTE_UPDATE packet
// 3) 		fetch data (distance vector) and src node ID
// 4) 		lock dv table and update dv table
// 5) 		update routing table if necessary with lock
// 6)     release locks
// 7)   if it is a MNP packet to itself 
// 8)     forward it to MRT layer w/ forwardsegToMRT()
// 9) 	if it is a MNP packet to others
// 10)    find the node ID of the next hop based on the routing table
// 11)    send it to the next hop w/ overlay_sendpkt()
// 2) close overlay conn
// 3) exit thread
void *pkthandler(void *arg) {

	pthread_exit(NULL);
}

// TODO: This thread sends out route update packets every 
// ROUTEUPDATE_INTERVAL. The route update packet contains this 
// node's distance vector. 
// Broadcasting is done by set the dest_nodeID in packet header as 
// BROADCAST_NODEID and use overlay_sendpkt() to send it out. 
// Pseudocode
// 1) get my node ID and number of neighbors
// 2) while(1)
//    Fill in mnp_pkt header with myNodeID, BROADCAST_NODEID and 
//			ROUTE_UPDATE
//    Cast the MNP packet data as pkt_routeupdate_t type, set the 
//      entryNum as the number of neighbors
// 		Lock the dv table, put distance vector into the packet data
//    Unlock the dv table
//    Set the length in packet header: sizeof(entryNum) + entryNum*
//      sizeof(routeupdate_entry_t)
//    if(overlay_sendpkt(BROADCAST_NODEID,&ru,overlay_conn < 0)
//      close(overlay_conn)
//      exit
//    Sleep ROUTEUPDATE_INTERVAL
void *routeupdate_daemon(void *arg) {

}

// TODO: this function opens a port on NETWORK_PORT and waits for 
// the TCP connection from local MRT process. 
// Pseudocode
// 1) create a socket listening on NETWORK_PORT
// 2) while (1)
// 3)   accept an connection from local MRT process
// 4) 	while (getsegToSend()) keep receiving segment and 
//      destination node ID from MRT
// 5) 		encapsulate the segment into a MNP packet
// 6)     find the node ID of the next hop based on the routing table
// 7)     send the packet to next hop using overlay_sendpkt()
// 8)   close the connection to local MRT
void waitTransport() {

}

// TODO: This function stops the MNP process. It closes all the 
// connections and frees all the dynamically allocated memory. 
// It is called when the MNP process receives a signal SIGINT.
// 1) close overlay connection if it exists
// 2) close the connection to MRT if it exists
// 3) destroy tables, free mutex
// 2) exit
void network_stop() {

}

